﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class Users
    {
        public string FirstName { get; set; }
        public string Lastname { get; set; }
        public string email { get; set; }

    }
}
